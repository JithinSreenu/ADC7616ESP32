# AD7616 + ESP32 – Arduino IDE

Port of the Zynq AD7616 SPI driver to ESP32 using Arduino IDE.

## Folder layout
esp32/
  AD7616.h          – ESP32 driver header
  AD7616.c          – ESP32 driver implementation
  AD7616_ESP32.ino  – Arduino sketch entry point, also contains pin mapping
  README.md

## Hardware wiring
AD7616 ↔ ESP32
- SDOA → MISO GPIO19
- SDI  → MOSI GPIO23
- SCLK → SCLK GPIO18
- CS   → GPIO5
- CONVST_A → GPIO15
- CONVST_B → GPIO2
- RESET    → GPIO4  active low
- BUSY     → GPIO34  input only

Use 3.3V logic level shifter if AD7616 is 5V. SPI Mode 2 CPOL=1 CPHA=0, max 50 MHz, use 10 MHz.

## Arduino IDE setup
1. Install ESP32 board package in Arduino IDE
2. Open AD7616_ESP32.ino
3. Select Tools → Board → ESP32 Dev Module
4. Upload

The sketch initializes SPI, configures pins, init AD7616, sets all channels to ±10V and prints a scan to Serial.

## Notes
- Arduino IDE requires an .ino file as entry point. The driver is pure C in .h/.c, the .ino only contains setup/loop and pin defines.
- `delayMicroseconds` replaces Xilinx `usleep`
- `Serial.printf` replaces `xil_printf`
- SPI is handled via Arduino `SPI.h` with `SPISettings(10MHz, MSBFIRST, SPI_MODE2)`
