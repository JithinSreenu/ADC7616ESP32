/******************************************************************************
 * @file    ad7616_drv.c
 * @brief   AD7616 16-bit Dual SAR ADC - SPI Driver Implementation
 *
 * All SPI calls use: XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, ByteCount);
 * All GPIO calls use: XGpio_DiscreteRead/Write(&GpioInstance, ...);
 *
 * SPI Mode 2: CPOL=1, CPHA=0
 *****************************************************************************/

#include "ad7616_drv.h"
#include "xil_printf.h"
#include "sleep.h"
#include <string.h>

/*============================================================================
 * PRIVATE STATE
 *===========================================================================*/

/** Shadow copy of config register */
static u16 gConfigReg = 0x000;

/** Per-channel range tracking (for voltage conversion) */
static AD7616_Range gRangeA[8];
static AD7616_Range gRangeB[8];

/** Full-scale voltage lookup (indexed by AD7616_Range) */
static const float gFullScale[] = { 10.0f, 2.5f, 5.0f, 10.0f };

/** Range register addresses for Side A / Side B */
static const u8 gRangeRegA[] = {
    AD7616_REG_RANGE_A1,   /* VA0,VA1 */
    AD7616_REG_RANGE_A2,   /* VA2,VA3 */
    AD7616_REG_RANGE_A3,   /* VA4,VA5 */
    AD7616_REG_RANGE_A4    /* VA6,VA7 */
};
static const u8 gRangeRegB[] = {
    AD7616_REG_RANGE_B1,   /* VB0,VB1 */
    AD7616_REG_RANGE_B2,   /* VB2,VB3 */
    AD7616_REG_RANGE_B3,   /* VB4,VB5 */
    AD7616_REG_RANGE_B4    /* VB6,VB7 */
};

/*============================================================================
 * INTERNAL: SPI TRANSFER HELPERS
 *
 * Every SPI call goes through XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, N)
 *===========================================================================*/

/**
 * @brief Send/receive 2 bytes (one 16-bit SPI frame).
 */
static int SpiTransfer16(u16 txWord, u16 *rxWord)
{
    u8 TxBuf[2];
    u8 RxBuf[2];
    int Status;

    /* Pack 16-bit word: MSB first */
    TxBuf[0] = (u8)(txWord >> 8);
    TxBuf[1] = (u8)(txWord & 0xFF);
    RxBuf[0] = 0;
    RxBuf[1] = 0;

    Status = XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, 2);

    if ((Status == XST_SUCCESS) && (rxWord != NULL)) {
        *rxWord = ((u16)RxBuf[0] << 8) | (u16)RxBuf[1];
    }

    return Status;
}

/**
 * @brief Send 4 dummy bytes, receive 32-bit conversion data (ChA + ChB).
 */
static int SpiReadConversion32(u16 *wordA, u16 *wordB)
{
    u8 TxBuf[4];
    u8 RxBuf[4];
    int Status;

    memset(TxBuf, 0, 4);
    memset(RxBuf, 0, 4);

    Status = XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, 4);

    if (Status == XST_SUCCESS) {
        if (wordA) *wordA = ((u16)RxBuf[0] << 8) | (u16)RxBuf[1];
        if (wordB) *wordB = ((u16)RxBuf[2] << 8) | (u16)RxBuf[3];
    }

    return Status;
}

/*============================================================================
 * INTERNAL: GPIO HELPERS
 *===========================================================================*/

static void GpioSetPin(u32 pinMask, int value)
{
    u32 reg = XGpio_DiscreteRead(&GpioInstance, AD7616_GPIO_OUT_CH);

    if (value)
        reg |= pinMask;
    else
        reg &= ~pinMask;

    XGpio_DiscreteWrite(&GpioInstance, AD7616_GPIO_OUT_CH, reg);
}

static u32 GpioGetPin(u32 pinMask)
{
    return XGpio_DiscreteRead(&GpioInstance, AD7616_GPIO_IN_CH) & pinMask;
}

/*============================================================================
 * INITIALIZATION
 *===========================================================================*/

int AD7616_Init(void)
{
    int Status;
    u16 readback;
    int i;

    /* Set GPIO directions: Ch1 outputs, Ch2 inputs */
    XGpio_SetDataDirection(&GpioInstance, AD7616_GPIO_OUT_CH, 0x00000000);
    XGpio_SetDataDirection(&GpioInstance, AD7616_GPIO_IN_CH,  0xFFFFFFFF);

    /* Idle state: CONVST high, RESET high */
    XGpio_DiscreteWrite(&GpioInstance, AD7616_GPIO_OUT_CH,
                        AD7616_PIN_CONVST_A | AD7616_PIN_CONVST_B | AD7616_PIN_RESET);

    /* Hardware reset */
    AD7616_HardReset();

    /* Default ranges: all ±10V */
    for (i = 0; i < 8; i++) {
        gRangeA[i] = AD7616_RANGE_PM10V;
        gRangeB[i] = AD7616_RANGE_PM10V;
    }
    gConfigReg = 0x000;

    /* Verify SPI communication: read config register */
    Status = AD7616_ReadReg(AD7616_REG_CONFIG, &readback);
    if (Status != XST_SUCCESS) {
        xil_printf("[AD7616] Init FAILED: SPI read error\r\n");
        return XST_FAILURE;
    }
    xil_printf("[AD7616] Init OK, config reg = 0x%03X\r\n", readback & 0x1FF);

    /* Select VA0/VB0 as default pair */
    AD7616_SelectChannel(0, 0);

    return XST_SUCCESS;
}

void AD7616_HardReset(void)
{
    GpioSetPin(AD7616_PIN_RESET, 0);    /* Assert RESET low  */
    usleep(10);                          /* Hold 10 us        */
    GpioSetPin(AD7616_PIN_RESET, 1);    /* Release RESET     */
    usleep(1000);                        /* Wait 1 ms recovery */
    xil_printf("[AD7616] Hardware reset done\r\n");
}

/*============================================================================
 * REGISTER ACCESS
 *===========================================================================*/

int AD7616_WriteReg(u8 addr, u16 data)
{
    u8 TxBuf[2];
    u8 RxBuf[2];
    u16 cmd;

    cmd = AD7616_WR_CMD(addr, data);

    TxBuf[0] = (u8)(cmd >> 8);
    TxBuf[1] = (u8)(cmd & 0xFF);
    RxBuf[0] = 0;
    RxBuf[1] = 0;

    return XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, 2);
}

int AD7616_ReadReg(u8 addr, u16 *data)
{
    u8 TxBuf[2];
    u8 RxBuf[2];
    u16 cmd;
    int Status;

    /*--- Transfer 1: Send read command ---*/
    cmd = AD7616_RD_CMD(addr);
    TxBuf[0] = (u8)(cmd >> 8);
    TxBuf[1] = (u8)(cmd & 0xFF);
    RxBuf[0] = 0;
    RxBuf[1] = 0;

    Status = XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, 2);
    if (Status != XST_SUCCESS)
        return Status;

    /*--- Transfer 2: Send NOP, receive data ---*/
    TxBuf[0] = 0x00;
    TxBuf[1] = 0x00;
    RxBuf[0] = 0;
    RxBuf[1] = 0;

    Status = XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, 2);
    if (Status != XST_SUCCESS)
        return Status;

    *data = (((u16)RxBuf[0] << 8) | (u16)RxBuf[1]) & 0x1FF;

    return XST_SUCCESS;
}

/*============================================================================
 * CHANNEL SELECTION
 *===========================================================================*/

int AD7616_SelectChannel(u8 chA, u8 chB)
{
    u16 val;

    if (chA > 7 || chB > 7)
        return XST_FAILURE;

    val = ((u16)(chB & 0x0F) << AD7616_CHB_SHIFT) |
          ((u16)(chA & 0x0F) << AD7616_CHA_SHIFT);

    return AD7616_WriteReg(AD7616_REG_CHANNEL, val);
}

/*============================================================================
 * INPUT RANGE
 *===========================================================================*/

int AD7616_SetRangeA(u8 ch, AD7616_Range range)
{
    u16 regVal;
    u8  regAddr;
    int Status;

    if (ch > 7) return XST_FAILURE;

    regAddr = gRangeRegA[ch / 2];

    Status = AD7616_ReadReg(regAddr, &regVal);
    if (Status != XST_SUCCESS) return Status;

    if (ch & 1) {  /* Odd channel */
        regVal &= ~(0x07u << AD7616_RANGE_ODD_SHIFT);
        regVal |= ((u16)range << AD7616_RANGE_ODD_SHIFT);
    } else {       /* Even channel */
        regVal &= ~(0x07u << AD7616_RANGE_EVEN_SHIFT);
        regVal |= ((u16)range << AD7616_RANGE_EVEN_SHIFT);
    }

    Status = AD7616_WriteReg(regAddr, regVal);
    if (Status == XST_SUCCESS)
        gRangeA[ch] = range;

    return Status;
}

int AD7616_SetRangeB(u8 ch, AD7616_Range range)
{
    u16 regVal;
    u8  regAddr;
    int Status;

    if (ch > 7) return XST_FAILURE;

    regAddr = gRangeRegB[ch / 2];

    Status = AD7616_ReadReg(regAddr, &regVal);
    if (Status != XST_SUCCESS) return Status;

    if (ch & 1) {
        regVal &= ~(0x07u << AD7616_RANGE_ODD_SHIFT);
        regVal |= ((u16)range << AD7616_RANGE_ODD_SHIFT);
    } else {
        regVal &= ~(0x07u << AD7616_RANGE_EVEN_SHIFT);
        regVal |= ((u16)range << AD7616_RANGE_EVEN_SHIFT);
    }

    Status = AD7616_WriteReg(regAddr, regVal);
    if (Status == XST_SUCCESS)
        gRangeB[ch] = range;

    return Status;
}

int AD7616_SetRangeAll(AD7616_Range range)
{
    u16 regVal;
    int i, Status;

    regVal = ((u16)range << AD7616_RANGE_ODD_SHIFT) |
             ((u16)range << AD7616_RANGE_EVEN_SHIFT);

    for (i = 0; i < 4; i++) {
        Status = AD7616_WriteReg(gRangeRegA[i], regVal);
        if (Status != XST_SUCCESS) return Status;

        Status = AD7616_WriteReg(gRangeRegB[i], regVal);
        if (Status != XST_SUCCESS) return Status;
    }

    for (i = 0; i < 8; i++) {
        gRangeA[i] = range;
        gRangeB[i] = range;
    }

    return XST_SUCCESS;
}

/*============================================================================
 * OVERSAMPLING
 *===========================================================================*/

int AD7616_SetOversampling(AD7616_Oversample ratio)
{
    gConfigReg &= ~AD7616_CFG_OS_MASK;
    gConfigReg |= ((u16)ratio << AD7616_CFG_OS_SHIFT) & AD7616_CFG_OS_MASK;

    return AD7616_WriteReg(AD7616_REG_CONFIG, gConfigReg);
}

/*============================================================================
 * CONVERSION
 *===========================================================================*/

void AD7616_TriggerConversion(void)
{
    /* Pulse CONVST_A and CONVST_B low simultaneously */
    GpioSetPin(AD7616_PIN_CONVST_A | AD7616_PIN_CONVST_B, 0);
    usleep(1);
    GpioSetPin(AD7616_PIN_CONVST_A | AD7616_PIN_CONVST_B, 1);
}

int AD7616_IsBusy(void)
{
    return (GpioGetPin(AD7616_PIN_BUSY) != 0) ? 1 : 0;
}

int AD7616_ReadConversion(AD7616_Result *result)
{
    u8 TxBuf[4];
    u8 RxBuf[4];
    int Status;

    memset(TxBuf, 0, 4);
    memset(RxBuf, 0, 4);

    /* 32-bit SPI transfer: clock out ChA[15:0] + ChB[15:0] */
    Status = XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, 4);

    if (Status == XST_SUCCESS) {
        result->raw_a = ((u16)RxBuf[0] << 8) | (u16)RxBuf[1];
        result->raw_b = ((u16)RxBuf[2] << 8) | (u16)RxBuf[3];
    }

    return Status;
}

int AD7616_ConvertAndRead(AD7616_Result *result)
{
    u32 timeout = 10000;
    int Status;

    /* 1. Trigger */
    AD7616_TriggerConversion();

    /* 2. Wait for BUSY to go low */
    while (AD7616_IsBusy() && (timeout > 0)) {
        usleep(1);
        timeout--;
    }
    if (timeout == 0) {
        xil_printf("[AD7616] BUSY timeout!\r\n");
        return XST_FAILURE;
    }

    /* 3. Read conversion data via SPI */
    Status = AD7616_ReadConversion(result);
    if (Status != XST_SUCCESS)
        return Status;

    /* 4. Compute voltages using current channel's range */
    u16 chReg;
    Status = AD7616_ReadReg(AD7616_REG_CHANNEL, &chReg);
    if (Status == XST_SUCCESS) {
        u8 chA = (chReg >> AD7616_CHA_SHIFT) & 0x0F;
        u8 chB = (chReg >> AD7616_CHB_SHIFT) & 0x0F;
        result->volt_a = AD7616_RawToVoltage(result->raw_a, gRangeA[chA]);
        result->volt_b = AD7616_RawToVoltage(result->raw_b, gRangeB[chB]);
    } else {
        result->volt_a = AD7616_RawToVoltage(result->raw_a, AD7616_RANGE_PM10V);
        result->volt_b = AD7616_RawToVoltage(result->raw_b, AD7616_RANGE_PM10V);
    }

    return XST_SUCCESS;
}

/*============================================================================
 * MULTI-CHANNEL
 *===========================================================================*/

int AD7616_ReadChannelPair(u8 chA, u8 chB, AD7616_Result *result)
{
    int Status;

    Status = AD7616_SelectChannel(chA, chB);
    if (Status != XST_SUCCESS) return Status;

    Status = AD7616_ConvertAndRead(result);
    if (Status != XST_SUCCESS) return Status;

    /* Override voltages with the explicitly requested channel ranges */
    result->volt_a = AD7616_RawToVoltage(result->raw_a, gRangeA[chA]);
    result->volt_b = AD7616_RawToVoltage(result->raw_b, gRangeB[chB]);

    return XST_SUCCESS;
}

int AD7616_ScanAllChannels(AD7616_Result results[8])
{
    int i, Status;

    for (i = 0; i < 8; i++) {
        Status = AD7616_ReadChannelPair((u8)i, (u8)i, &results[i]);
        if (Status != XST_SUCCESS) {
            xil_printf("[AD7616] Scan failed on pair %d\r\n", i);
            return Status;
        }
    }

    return XST_SUCCESS;
}

/*============================================================================
 * SEQUENCER
 *===========================================================================*/

int AD7616_SetupSequencer(const u8 chA_list[], const u8 chB_list[], u8 numPairs)
{
    int i, Status;

    if (numPairs == 0 || numPairs > 8) return XST_FAILURE;

    /* Disable sequencer first */
    AD7616_DisableSequencer();

    /* Program stack registers */
    for (i = 0; i < (int)numPairs; i++) {
        Status = AD7616_WriteReg(AD7616_REG_SEQ_A(i), (u16)(chA_list[i] & 0x07));
        if (Status != XST_SUCCESS) return Status;

        Status = AD7616_WriteReg(AD7616_REG_SEQ_B(i), (u16)(chB_list[i] & 0x07));
        if (Status != XST_SUCCESS) return Status;
    }

    /* Enable sequencer + burst mode */
    gConfigReg &= ~AD7616_CFG_SEQEN_MASK;
    gConfigReg |= (0x02u << AD7616_CFG_SEQEN_SHIFT);  /* Auto-sequence */
    gConfigReg |= AD7616_CFG_BURSTEN;

    Status = AD7616_WriteReg(AD7616_REG_CONFIG, gConfigReg);
    xil_printf("[AD7616] Sequencer enabled, %d pairs\r\n", numPairs);

    return Status;
}

int AD7616_DisableSequencer(void)
{
    gConfigReg &= ~AD7616_CFG_SEQEN_MASK;
    gConfigReg &= ~AD7616_CFG_BURSTEN;

    return AD7616_WriteReg(AD7616_REG_CONFIG, gConfigReg);
}

/*============================================================================
 * UTILITIES
 *===========================================================================*/

float AD7616_RawToVoltage(u16 raw, AD7616_Range range)
{
    float fs = gFullScale[range & 0x03];

    if (range == AD7616_RANGE_0_10V) {
        /* Unipolar: 0 to 10V, unsigned 16-bit */
        return ((float)raw / 65536.0f) * fs;
    } else {
        /* Bipolar: twos complement 16-bit */
        return ((float)((s16)raw) / 32768.0f) * fs;
    }
}

void AD7616_PrintResult(u8 chA, u8 chB, const AD7616_Result *result)
{
    s32 mV_A = (s32)(result->volt_a * 1000.0f);
    s32 mV_B = (s32)(result->volt_b * 1000.0f);

    s32 absA = (mV_A < 0) ? -mV_A : mV_A;
    s32 absB = (mV_B < 0) ? -mV_B : mV_B;

    xil_printf("VA%d: 0x%04X = %s%d.%03dV | VB%d: 0x%04X = %s%d.%03dV\r\n",
               chA, result->raw_a,
               (mV_A < 0) ? "-" : " ", absA / 1000, absA % 1000,
               chB, result->raw_b,
               (mV_B < 0) ? "-" : " ", absB / 1000, absB % 1000);
}
