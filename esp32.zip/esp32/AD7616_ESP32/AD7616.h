#ifndef AD7616_H
#define AD7616_H

#include <Arduino.h>
#include <SPI.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    AD7616_RANGE_PM10V = 0,
    AD7616_RANGE_PM2V5 = 1,
    AD7616_RANGE_PM5V  = 2,
    AD7616_RANGE_0_10V = 3
} AD7616_Range;

typedef enum {
    AD7616_OS_NONE = 0,
    AD7616_OS_2X = 1,
    AD7616_OS_4X = 2,
    AD7616_OS_8X = 3,
    AD7616_OS_16X = 4,
    AD7616_OS_32X = 5,
    AD7616_OS_64X = 6,
    AD7616_OS_128X = 7
} AD7616_Oversample;

typedef struct {
    uint16_t raw_a;
    uint16_t raw_b;
    float volt_a;
    float volt_b;
} AD7616_Result;

/* Public API */
int  AD7616_Init(void);
void AD7616_HardReset(void);
int  AD7616_WriteReg(uint8_t addr, uint16_t data);
int  AD7616_ReadReg(uint8_t addr, uint16_t *data);
int  AD7616_SelectChannel(uint8_t chA, uint8_t chB);
int  AD7616_SetRangeA(uint8_t ch, AD7616_Range range);
int  AD7616_SetRangeB(uint8_t ch, AD7616_Range range);
int  AD7616_SetRangeAll(AD7616_Range range);
int  AD7616_SetOversampling(AD7616_Oversample ratio);
int  AD7616_ConvertAndRead(AD7616_Result *result);
void AD7616_TriggerConversion(void);
int  AD7616_IsBusy(void);
int  AD7616_ReadConversion(AD7616_Result *result);
int  AD7616_ReadChannelPair(uint8_t chA, uint8_t chB, AD7616_Result *result);
int  AD7616_ScanAllChannels(AD7616_Result results[8]);
int  AD7616_SetupSequencer(const uint8_t chA_list[], const uint8_t chB_list[], uint8_t numPairs);
int  AD7616_DisableSequencer(void);
float AD7616_RawToVoltage(uint16_t raw, AD7616_Range range);
void AD7616_PrintResult(uint8_t chA, uint8_t chB, const AD7616_Result *result);

#ifdef __cplusplus
}
#endif

#endif
