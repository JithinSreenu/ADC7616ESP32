/******************************************************************************
 *
 *  FILE:    ad7616_drv_explained.c
 *  TITLE:   AD7616 SPI Driver — DETAILED REFERENCE IMPLEMENTATION
 *
 *  PURPOSE: This is a line-by-line commented educational copy of ad7616_drv.c.
 *           Every function, every SPI transfer, and every bit manipulation is
 *           explained so you understand exactly what happens on the wire.
 *
 *  CORE CONCEPT:
 *  All communication with the AD7616 ADC goes through ONE Xilinx API call:
 *
 *      XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, ByteCount);
 *
 *  Where:
 *    &SpiInstance = pointer to the AXI Quad SPI hardware instance
 *    TxBuf        = array of bytes to SEND to the ADC (MOSI line)
 *    RxBuf        = array of bytes RECEIVED from the ADC (MISO / SDOA line)
 *    ByteCount    = number of bytes to transfer (2 for register, 4 for data)
 *
 *  During each transfer, data flows in BOTH directions simultaneously:
 *    - Zynq sends TxBuf bytes out on MOSI (SDI pin of AD7616)
 *    - AD7616 sends data back on MISO (SDOA pin) into RxBuf
 *
 *  SPI TIMING:
 *    The AXI Quad SPI handles:
 *      - Asserting CS (chip select) LOW at the start of transfer
 *      - Generating SCLK pulses for each bit
 *      - Releasing CS HIGH at the end of transfer
 *    You don't need to manage these signals manually.
 *
 *****************************************************************************/

#include "ad7616_drv_explained.h"
#include "xil_printf.h"     /* xil_printf() — lightweight printf for Zynq     */
#include "sleep.h"          /* usleep() — microsecond delay                    */
#include <string.h>         /* memset() — zero out buffers                     */


/*==============================================================================
 *
 *  PRIVATE STATE VARIABLES
 *
 *  These are internal to the driver. They keep track of the ADC's current
 *  configuration so we can:
 *    1. Do read-modify-write on registers without re-reading every time
 *    2. Know each channel's voltage range for raw-to-voltage conversion
 *
 *============================================================================*/

/*
 * Shadow copy of the Configuration Register (0x02).
 *
 * WHY: When we change one setting (e.g., oversampling), we need to write
 * the ENTIRE 9-bit register. If we just wrote the new oversampling bits,
 * we'd accidentally clear the sequencer bits. So we keep a local copy,
 * modify the bits we want, then write the whole thing.
 */
static u16 gConfigReg = 0x000;

/*
 * Per-channel range tracking.
 *
 * We store the range setting for each of the 16 channels so that when
 * we convert raw ADC codes to voltages, we know what full-scale voltage
 * to use. For example:
 *   gRangeA[3] = AD7616_RANGE_PM5V  means VA3 is set to ±5V
 *   gRangeB[0] = AD7616_RANGE_PM10V means VB0 is set to ±10V
 */
static AD7616_Range gRangeA[8];   /* VA0-VA7 range settings */
static AD7616_Range gRangeB[8];   /* VB0-VB7 range settings */

/*
 * Full-scale voltage lookup table.
 *
 * Indexed by AD7616_Range enum value:
 *   gFullScale[0] = 10.0  (for ±10V)
 *   gFullScale[1] = 2.5   (for ±2.5V)
 *   gFullScale[2] = 5.0   (for ±5V)
 *   gFullScale[3] = 10.0  (for 0-10V, full scale is 10V)
 */
static const float gFullScale[] = { 10.0f, 2.5f, 5.0f, 10.0f };

/*
 * Range register address lookup tables.
 *
 * Channel 0,1 use register index 0; channel 2,3 use index 1; etc.
 * So for channel N, the register is gRangeRegA[N/2].
 */
static const u8 gRangeRegA[] = {
    AD7616_REG_RANGE_A1,   /* Index 0: VA0, VA1 */
    AD7616_REG_RANGE_A2,   /* Index 1: VA2, VA3 */
    AD7616_REG_RANGE_A3,   /* Index 2: VA4, VA5 */
    AD7616_REG_RANGE_A4    /* Index 3: VA6, VA7 */
};
static const u8 gRangeRegB[] = {
    AD7616_REG_RANGE_B1,   /* Index 0: VB0, VB1 */
    AD7616_REG_RANGE_B2,   /* Index 1: VB2, VB3 */
    AD7616_REG_RANGE_B3,   /* Index 2: VB4, VB5 */
    AD7616_REG_RANGE_B4    /* Index 3: VB6, VB7 */
};


/*==============================================================================
 *
 *  INTERNAL: GPIO HELPER FUNCTIONS
 *
 *  The AD7616 needs 3 output pins (CONVST_A, CONVST_B, RESET) and
 *  1 input pin (BUSY). These are controlled via the AXI GPIO IP core.
 *
 *  The AXI GPIO register is a simple bit-mapped I/O register:
 *    - Writing a bit to 1 drives the pin HIGH
 *    - Writing a bit to 0 drives the pin LOW
 *    - Reading a bit returns the current pin state
 *
 *============================================================================*/

/*
 * GpioSetPin() — Set one or more output pins HIGH or LOW.
 *
 * How it works:
 *   1. Read the current state of ALL output pins
 *   2. Set or clear the target pin bit(s)
 *   3. Write the modified value back
 *
 * This read-modify-write ensures we don't accidentally change other pins.
 *
 * Example:
 *   GpioSetPin(AD7616_PIN_RESET, 0);  // Drive RESET LOW (assert reset)
 *   GpioSetPin(AD7616_PIN_RESET, 1);  // Drive RESET HIGH (release reset)
 *   GpioSetPin(AD7616_PIN_CONVST_A | AD7616_PIN_CONVST_B, 0);  // Both LOW
 */
static void GpioSetPin(u32 pinMask, int value)
{
    /* Step 1: Read current output register value */
    u32 reg = XGpio_DiscreteRead(&GpioInstance, AD7616_GPIO_OUT_CH);

    /* Step 2: Set or clear the target bit(s) */
    if (value)
        reg |= pinMask;     /* OR to set bits HIGH   */
    else
        reg &= ~pinMask;    /* AND-NOT to set bits LOW */

    /* Step 3: Write modified value back to the GPIO register */
    XGpio_DiscreteWrite(&GpioInstance, AD7616_GPIO_OUT_CH, reg);
}

/*
 * GpioGetPin() — Read the state of an input pin.
 *
 * Returns: Non-zero if the pin is HIGH, zero if LOW.
 *
 * Example:
 *   if (GpioGetPin(AD7616_PIN_BUSY)) {
 *       // ADC is still converting...
 *   }
 */
static u32 GpioGetPin(u32 pinMask)
{
    return XGpio_DiscreteRead(&GpioInstance, AD7616_GPIO_IN_CH) & pinMask;
}


/*==============================================================================
 *
 *  INITIALIZATION
 *
 *============================================================================*/

/*
 * AD7616_Init() — Initialize the AD7616 ADC.
 *
 * PREREQUISITES:
 *   Before calling this, you MUST have already:
 *   1. Called XSpi_CfgInitialize() and XSpi_Start() on SpiInstance
 *   2. Called XGpio_Initialize() on GpioInstance
 *
 * WHAT THIS FUNCTION DOES:
 *
 *   [1] Configure GPIO pin directions:
 *       - Channel 1 = all outputs (for CONVST_A, CONVST_B, RESET)
 *       - Channel 2 = all inputs  (for BUSY)
 *
 *   [2] Set idle state:
 *       - CONVST_A = HIGH (not triggering)
 *       - CONVST_B = HIGH (not triggering)
 *       - RESET = HIGH (not in reset)
 *
 *   [3] Perform hardware reset:
 *       - Pulse RESET LOW for 10µs, then wait 1ms
 *       - This puts all AD7616 registers back to power-on defaults
 *
 *   [4] Initialize software state:
 *       - Set all range tracking to ±10V (the AD7616 default)
 *       - Clear config shadow register
 *
 *   [5] Verify SPI communication:
 *       - Read the config register — should return 0x000 after reset
 *       - If this fails, SPI wiring or settings are wrong
 *
 *   [6] Set default channel to VA0/VB0
 *
 * RETURNS: XST_SUCCESS if everything is OK, XST_FAILURE if SPI fails
 */
int AD7616_Init(void)
{
    int Status;
    u16 readback;
    int i;

    /*
     * [1] GPIO Direction Setup
     *
     * XGpio_SetDataDirection(instance, channel, direction_mask)
     *   direction_mask: 0 = output, 1 = input (per bit)
     *
     *   0x00000000 = ALL bits are outputs
     *   0xFFFFFFFF = ALL bits are inputs
     */
    XGpio_SetDataDirection(&GpioInstance, AD7616_GPIO_OUT_CH, 0x00000000);  /* outputs */
    XGpio_SetDataDirection(&GpioInstance, AD7616_GPIO_IN_CH,  0xFFFFFFFF); /* inputs  */

    /*
     * [2] Set idle GPIO state
     *
     * CONVST_A = 1 (HIGH = idle, not triggering conversion)
     * CONVST_B = 1 (HIGH = idle)
     * RESET    = 1 (HIGH = not in reset; LOW would assert reset)
     */
    XGpio_DiscreteWrite(&GpioInstance, AD7616_GPIO_OUT_CH,
                        AD7616_PIN_CONVST_A | AD7616_PIN_CONVST_B | AD7616_PIN_RESET);

    /*
     * [3] Hardware reset — clears all AD7616 internal registers to defaults
     */
    AD7616_HardReset();

    /*
     * [4] Initialize software state to match post-reset defaults
     */
    for (i = 0; i < 8; i++) {
        gRangeA[i] = AD7616_RANGE_PM10V;   /* Default: ±10V */
        gRangeB[i] = AD7616_RANGE_PM10V;
    }
    gConfigReg = 0x000;   /* Config register is all zeros after reset */

    /*
     * [5] Verify SPI communication
     *
     * Read the config register. After reset it should be 0x000.
     * If we get 0x1FF or garbage, SPI is not working (check wiring,
     * CPOL/CPHA settings, or CS connection).
     *
     * This internally does:
     *   XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, 2);  // send read cmd
     *   XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, 2);  // get data back
     */
    Status = AD7616_ReadReg(AD7616_REG_CONFIG, &readback);
    if (Status != XST_SUCCESS) {
        xil_printf("[AD7616] Init FAILED: SPI read error\r\n");
        return XST_FAILURE;
    }
    xil_printf("[AD7616] Init OK, config reg = 0x%03X\r\n", readback & 0x1FF);

    /*
     * [6] Select default channel pair: VA0 + VB0
     */
    AD7616_SelectChannel(0, 0);

    return XST_SUCCESS;
}


/*
 * AD7616_HardReset() — Pulse the RESET pin to reset the AD7616.
 *
 * Timing:
 *   1. Drive RESET pin LOW (assert reset)
 *   2. Wait 10 µs (datasheet minimum is ~100 ns, we use 10 µs for safety)
 *   3. Drive RESET pin HIGH (release reset)
 *   4. Wait 1 ms for the AD7616 to complete its internal power-up sequence
 *
 * After this, all registers are at their default values:
 *   - Config = 0x000 (no oversampling, no sequencer)
 *   - Channel = 0x000 (VA0 + VB0)
 *   - All ranges = ±10V
 */
void AD7616_HardReset(void)
{
    GpioSetPin(AD7616_PIN_RESET, 0);    /* Drive RESET LOW   */
    usleep(10);                          /* Hold for 10 µs    */
    GpioSetPin(AD7616_PIN_RESET, 1);    /* Release RESET     */
    usleep(1000);                        /* Wait 1 ms for recovery */
    xil_printf("[AD7616] Hardware reset done\r\n");
}


/*==============================================================================
 *
 *  REGISTER ACCESS — The Core SPI Communication
 *
 *  These two functions are the foundation of the entire driver. Every other
 *  function (channel select, range set, etc.) ultimately calls WriteReg or
 *  ReadReg, which call XSpi_Transfer().
 *
 *============================================================================*/

/*
 * AD7616_WriteReg() — Write a value to an AD7616 register.
 *
 * SPI WIRE PROTOCOL:
 *
 *   We send a 16-bit frame: [1][ADDR 6bits][DATA 9bits]
 *
 *   Example: Write 0x038 to register 0x02 (enable 8x oversampling)
 *
 *     Frame = AD7616_WR_CMD(0x02, 0x038)
 *           = 0x8000 | (0x02 << 9) | 0x038
 *           = 0x8000 | 0x0400 | 0x038
 *           = 0x8438
 *
 *     In binary: 1_000010_000111000
 *                ^  ^addr   ^data
 *                WR=1
 *
 *     Byte split: TxBuf[0] = 0x84 (sent first, MSB)
 *                 TxBuf[1] = 0x38 (sent second, LSB)
 *
 *   What happens on the wires:
 *
 *     CS   ────┐                          ┌────   (LOW during transfer)
 *              └──────────────────────────┘
 *
 *     SCLK     ┐┌┐┌┐┌┐┌┐┌┐┌┐┌┐┌┐┌┐┌┐┌┐┌┐┌┐┌┐┌   (16 clock pulses)
 *              └┘└┘└┘└┘└┘└┘└┘└┘└┘└┘└┘└┘└┘└┘└┘└┘
 *
 *     MOSI  ───[1][0][0][0][0][1][0][0][0][0][1][1][1][0][0][0]
 *              (MSB first: bit15 bit14 ... bit1 bit0)
 *
 *   The ADC latches these bits on the falling edge of SCLK (SPI Mode 2).
 *   The register write takes effect on the rising edge of CS.
 */
int AD7616_WriteReg(u8 addr, u16 data)
{
    u8 TxBuf[2];     /* 2 bytes to send (16-bit frame) */
    u8 RxBuf[2];     /* 2 bytes received (ignored for writes) */
    u16 cmd;

    /*
     * Build the 16-bit write command:
     *   Bit 15 = 1 (write)
     *   Bits 14:9 = register address
     *   Bits 8:0 = data value
     */
    cmd = AD7616_WR_CMD(addr, data);

    /*
     * Split 16-bit word into two bytes (MSB first).
     * SPI sends TxBuf[0] first, which must be the MSB.
     */
    TxBuf[0] = (u8)(cmd >> 8);      /* Upper byte (contains WR bit + addr) */
    TxBuf[1] = (u8)(cmd & 0xFF);    /* Lower byte (contains lower data bits) */

    /* Clear receive buffer (we don't need the response for writes) */
    RxBuf[0] = 0;
    RxBuf[1] = 0;

    /*
     * *** THE ACTUAL SPI TRANSFER ***
     *
     * XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, 2);
     *
     * This single call:
     *   1. Asserts CS LOW
     *   2. Clocks out TxBuf[0] bit-by-bit on MOSI (8 bits)
     *      While receiving 8 bits on MISO into RxBuf[0]
     *   3. Clocks out TxBuf[1] on MOSI (8 more bits)
     *      While receiving 8 bits on MISO into RxBuf[1]
     *   4. Releases CS HIGH
     *
     * Total: 16 SCLK pulses, CS LOW for the entire duration.
     * ByteCount = 2 means 2 bytes = 16 bits.
     */
    return XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, 2);
}


/*
 * AD7616_ReadReg() — Read a value from an AD7616 register.
 *
 * WHY TWO TRANSFERS?
 *
 *   The AD7616 uses a "pipelined" read protocol. When you send a read
 *   command, the ADC doesn't have the data ready instantly. It needs
 *   until the NEXT CS cycle to output the data. So:
 *
 *     Transfer 1 (send read command):
 *       MOSI → [0][ADDR][don't care]     (we tell ADC which register)
 *       MISO ← [previous data or junk]   (ADC hasn't fetched data yet)
 *
 *     Transfer 2 (get data):
 *       MOSI → [0x0000 NOP]              (we send nothing meaningful)
 *       MISO ← [requested register data] (ADC sends the data we asked for)
 *
 *   This is standard for many ADCs — it's called "read-back on next frame."
 *
 * COMPLETE WIRE DIAGRAM:
 *
 *   Transfer 1:
 *     CS   ──┐                    ┌──   ← CS HIGH between transfers
 *            └────────────────────┘
 *     MOSI   [0][addr bits][0000]       ← Read command
 *     MISO   [xxxxxxxxxxxxx]            ← Don't care (old data)
 *
 *   Transfer 2:
 *     CS   ──┐                    ┌──
 *            └────────────────────┘
 *     MOSI   [0000000000000000]         ← NOP (all zeros)
 *     MISO   [register data, 16 bits]   ← THIS is what we want!
 *
 *   We extract bits [8:0] from the MISO data (9-bit register value).
 */
int AD7616_ReadReg(u8 addr, u16 *data)
{
    u8 TxBuf[2];
    u8 RxBuf[2];
    u16 cmd;
    int Status;

    /*
     * ===== TRANSFER 1: Send the read command =====
     *
     * Build read frame: bit15=0 (read), bits[14:9]=addr, bits[8:0]=don't care
     */
    cmd = AD7616_RD_CMD(addr);

    TxBuf[0] = (u8)(cmd >> 8);
    TxBuf[1] = (u8)(cmd & 0xFF);
    RxBuf[0] = 0;
    RxBuf[1] = 0;

    /*
     * Send the read command. The ADC now knows we want to read register
     * at 'addr'. It will prepare the data for the next transfer.
     */
    Status = XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, 2);
    if (Status != XST_SUCCESS)
        return Status;

    /* RxBuf here contains old/irrelevant data — discard it */

    /*
     * ===== TRANSFER 2: Clock out the data =====
     *
     * Send NOP (0x0000) on MOSI. The ADC responds with the register
     * data on MISO (SDOA pin).
     */
    TxBuf[0] = 0x00;    /* NOP upper byte */
    TxBuf[1] = 0x00;    /* NOP lower byte */
    RxBuf[0] = 0;
    RxBuf[1] = 0;

    Status = XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, 2);
    if (Status != XST_SUCCESS)
        return Status;

    /*
     * Extract the 9-bit register value from the received 16-bit word.
     *
     * RxBuf[0] = upper byte (received first = MSB)
     * RxBuf[1] = lower byte (received second = LSB)
     *
     * Reassemble: (RxBuf[0] << 8) | RxBuf[1] = 16-bit value
     * Mask with 0x1FF to extract only the 9-bit data field.
     */
    *data = (((u16)RxBuf[0] << 8) | (u16)RxBuf[1]) & 0x1FF;

    return XST_SUCCESS;
}


/*==============================================================================
 *
 *  CHANNEL SELECTION
 *
 *  The AD7616 converts ONE pair at a time: one channel from Side A and one
 *  from Side B. You select which pair by writing the Channel Register (0x03).
 *
 *============================================================================*/

/*
 * AD7616_SelectChannel() — Choose which VA and VB channels to convert.
 *
 * Register 0x03 format:
 *   Bits [3:0] = CHA (Side A channel, 0-7)
 *   Bits [7:4] = CHB (Side B channel, 0-7)
 *
 * Example: Select VA3 and VB5
 *   chA = 3 → bits[3:0] = 0011
 *   chB = 5 → bits[7:4] = 0101
 *   Register value = (5 << 4) | 3 = 0x053
 *   This writes: AD7616_WriteReg(0x03, 0x053)
 *   Which calls: XSpi_Transfer(&SpiInstance, {0x86, 0x53}, RxBuf, 2)
 */
int AD7616_SelectChannel(u8 chA, u8 chB)
{
    u16 val;

    /* Validate channel numbers (0-7 only) */
    if (chA > 7 || chB > 7)
        return XST_FAILURE;

    /*
     * Pack both channel numbers into a 9-bit register value:
     *   val = (chB << 4) | chA
     *
     * Example: chA=3, chB=5
     *   val = (5 << 4) | 3 = 0x50 | 0x03 = 0x53
     */
    val = ((u16)(chB & 0x0F) << AD7616_CHB_SHIFT) |
          ((u16)(chA & 0x0F) << AD7616_CHA_SHIFT);

    /* Write to channel register via SPI */
    return AD7616_WriteReg(AD7616_REG_CHANNEL, val);
}


/*==============================================================================
 *
 *  INPUT RANGE CONFIGURATION
 *
 *  Each range register controls TWO channels (a pair). We use
 *  read-modify-write to change one channel without affecting the other.
 *
 *============================================================================*/

/*
 * AD7616_SetRangeA() — Set voltage range for one Side A channel.
 *
 * The range register format:
 *   Bits [2:0] = Range for EVEN channel (VA0, VA2, VA4, VA6)
 *   Bits [5:3] = Range for ODD channel  (VA1, VA3, VA5, VA7)
 *
 * Example: Set VA3 to ±5V
 *   ch = 3
 *   Register = gRangeRegA[3/2] = gRangeRegA[1] = 0x05 (Range A2, for VA2/VA3)
 *   ch is ODD (3 % 2 = 1), so we modify bits [5:3]
 *
 *   Steps:
 *   1. Read current register 0x05 via SPI (2 transfers)
 *   2. Clear bits [5:3]: regVal &= ~(0x07 << 3)
 *   3. Set new range:     regVal |= (0x02 << 3)   (0x02 = ±5V)
 *   4. Write register 0x05 via SPI (1 transfer)
 *
 * Total SPI transactions: 3 calls to XSpi_Transfer (2 for read + 1 for write)
 */
int AD7616_SetRangeA(u8 ch, AD7616_Range range)
{
    u16 regVal;
    u8  regAddr;
    int Status;

    if (ch > 7) return XST_FAILURE;

    /* Determine which range register controls this channel */
    regAddr = gRangeRegA[ch / 2];     /* ch 0,1→index 0; ch 2,3→index 1; etc. */

    /* Read current register value (read-modify-write pattern) */
    Status = AD7616_ReadReg(regAddr, &regVal);
    if (Status != XST_SUCCESS) return Status;

    if (ch & 1) {
        /* ODD channel (1, 3, 5, 7) → bits [5:3] */
        regVal &= ~(0x07u << AD7616_RANGE_ODD_SHIFT);      /* Clear old range */
        regVal |= ((u16)range << AD7616_RANGE_ODD_SHIFT);   /* Set new range   */
    } else {
        /* EVEN channel (0, 2, 4, 6) → bits [2:0] */
        regVal &= ~(0x07u << AD7616_RANGE_EVEN_SHIFT);
        regVal |= ((u16)range << AD7616_RANGE_EVEN_SHIFT);
    }

    /* Write modified register back */
    Status = AD7616_WriteReg(regAddr, regVal);

    /* Update our local tracking if write succeeded */
    if (Status == XST_SUCCESS)
        gRangeA[ch] = range;

    return Status;
}


/*
 * AD7616_SetRangeB() — Same as SetRangeA but for Side B channels.
 *
 * Identical logic, just uses gRangeRegB[] table and gRangeB[] tracking.
 */
int AD7616_SetRangeB(u8 ch, AD7616_Range range)
{
    u16 regVal;
    u8  regAddr;
    int Status;

    if (ch > 7) return XST_FAILURE;

    regAddr = gRangeRegB[ch / 2];

    Status = AD7616_ReadReg(regAddr, &regVal);
    if (Status != XST_SUCCESS) return Status;

    if (ch & 1) {
        regVal &= ~(0x07u << AD7616_RANGE_ODD_SHIFT);
        regVal |= ((u16)range << AD7616_RANGE_ODD_SHIFT);
    } else {
        regVal &= ~(0x07u << AD7616_RANGE_EVEN_SHIFT);
        regVal |= ((u16)range << AD7616_RANGE_EVEN_SHIFT);
    }

    Status = AD7616_WriteReg(regAddr, regVal);
    if (Status == XST_SUCCESS)
        gRangeB[ch] = range;

    return Status;
}


/*
 * AD7616_SetRangeAll() — Set all 16 channels to the same range.
 *
 * Writes all 8 range registers (4 for Side A, 4 for Side B).
 * Each register gets both fields set to the same range.
 *
 * Total SPI transactions: 8 writes × 1 transfer each = 8 XSpi_Transfer calls.
 */
int AD7616_SetRangeAll(AD7616_Range range)
{
    u16 regVal;
    int i, Status;

    /*
     * Build a register value where BOTH channels have the same range.
     * Bits [2:0] = range (even channel)
     * Bits [5:3] = range (odd channel)
     */
    regVal = ((u16)range << AD7616_RANGE_ODD_SHIFT) |
             ((u16)range << AD7616_RANGE_EVEN_SHIFT);

    /* Write all 4 Side A range registers */
    for (i = 0; i < 4; i++) {
        Status = AD7616_WriteReg(gRangeRegA[i], regVal);
        if (Status != XST_SUCCESS) return Status;

        Status = AD7616_WriteReg(gRangeRegB[i], regVal);
        if (Status != XST_SUCCESS) return Status;
    }

    /* Update all local tracking */
    for (i = 0; i < 8; i++) {
        gRangeA[i] = range;
        gRangeB[i] = range;
    }

    return XST_SUCCESS;
}


/*==============================================================================
 *
 *  OVERSAMPLING
 *
 *============================================================================*/

/*
 * AD7616_SetOversampling() — Set the hardware oversampling ratio.
 *
 * Modifies bits [5:3] (OS[2:0]) of the config register using the shadow copy.
 *
 * Example: Set 8x oversampling
 *   ratio = AD7616_OS_8X = 3
 *   gConfigReg bits[5:3] = 011 = 0x018
 *   Writes: AD7616_WriteReg(0x02, 0x018)
 *   Which calls: XSpi_Transfer(&SpiInstance, {0x84, 0x18}, RxBuf, 2)
 */
int AD7616_SetOversampling(AD7616_Oversample ratio)
{
    /* Clear the old oversampling bits in our shadow register */
    gConfigReg &= ~AD7616_CFG_OS_MASK;

    /* Set the new oversampling bits */
    gConfigReg |= ((u16)ratio << AD7616_CFG_OS_SHIFT) & AD7616_CFG_OS_MASK;

    /* Write the entire config register to the AD7616 */
    return AD7616_WriteReg(AD7616_REG_CONFIG, gConfigReg);
}


/*==============================================================================
 *
 *  CONVERSION — The Core Data Acquisition Flow
 *
 *  This is where the actual ADC measurement happens. The sequence is:
 *
 *    1. TRIGGER: Pulse CONVST pins LOW → starts the analog-to-digital conversion
 *    2. WAIT:    Poll the BUSY pin until it goes LOW → conversion is done (~1µs)
 *    3. READ:    Do a 32-bit SPI transfer → get the digital result
 *
 *  The 32-bit SPI readout format on SDOA (MISO):
 *
 *    ┌──────────────────────┬──────────────────────┐
 *    │ Bits [31:16] (first) │ Bits [15:0] (second)  │
 *    │ Channel A result     │ Channel B result       │
 *    │ (16-bit)             │ (16-bit)               │
 *    └──────────────────────┴──────────────────────┘
 *
 *    Mapped to 4 bytes:
 *      RxBuf[0] = ChA upper byte (MSB)
 *      RxBuf[1] = ChA lower byte (LSB)
 *      RxBuf[2] = ChB upper byte (MSB)
 *      RxBuf[3] = ChB lower byte (LSB)
 *
 *============================================================================*/

/*
 * AD7616_TriggerConversion() — Start a conversion by pulsing CONVST.
 *
 * CONVST TIMING:
 *   CONVST is active LOW. We pulse it LOW for 1µs then return it HIGH.
 *   Both CONVST_A and CONVST_B are pulsed together for simultaneous sampling.
 *
 *   CONVST_A ──────┐     ┌──────────
 *                   └─────┘
 *   CONVST_B ──────┐     ┌──────────
 *                   └─────┘
 *                   ←1µs →
 *
 *   After this pulse, the BUSY pin goes HIGH and stays HIGH until the
 *   conversion is complete (typically ~1µs for no oversampling).
 */
void AD7616_TriggerConversion(void)
{
    /* Drive both CONVST pins LOW (starts conversion) */
    GpioSetPin(AD7616_PIN_CONVST_A | AD7616_PIN_CONVST_B, 0);

    /* Hold LOW for 1µs (datasheet minimum is ~20ns, we use 1µs for margin) */
    usleep(1);

    /* Return CONVST pins HIGH (idle state) */
    GpioSetPin(AD7616_PIN_CONVST_A | AD7616_PIN_CONVST_B, 1);
}


/*
 * AD7616_IsBusy() — Check if a conversion is in progress.
 *
 * BUSY PIN:
 *   HIGH (1) = conversion in progress, DO NOT read data yet
 *   LOW  (0) = conversion complete, data is ready to read
 *
 * Returns: 1 if busy, 0 if ready
 */
int AD7616_IsBusy(void)
{
    return (GpioGetPin(AD7616_PIN_BUSY) != 0) ? 1 : 0;
}


/*
 * AD7616_ReadConversion() — Read the 32-bit conversion result via SPI.
 *
 * IMPORTANT: Call this ONLY after BUSY goes LOW. If you read while BUSY
 * is still HIGH, you'll get corrupted data.
 *
 * SPI WIRE PROTOCOL:
 *
 *   We send 4 bytes of zeros (NOP) on MOSI.
 *   The ADC sends 4 bytes of conversion data on MISO (SDOA).
 *   Both happen simultaneously during the same 32 SCLK pulses.
 *
 *   CS   ──┐                                              ┌──
 *           └──────────────────────────────────────────────┘
 *
 *   SCLK    ┐┌┐┌┐┌┐┌┐┌ ... (32 clock pulses) ... ┐┌┐┌┐┌┐┌
 *           └┘└┘└┘└┘└┘                             └┘└┘└┘└┘
 *
 *   MOSI    [00000000][00000000][00000000][00000000]  (we send zeros)
 *
 *   MISO    [ChA MSB ][ChA LSB ][ChB MSB ][ChB LSB ]  (ADC sends data)
 *              RxBuf[0] RxBuf[1]  RxBuf[2]  RxBuf[3]
 *
 *   Channel A result = (RxBuf[0] << 8) | RxBuf[1]  (16-bit value)
 *   Channel B result = (RxBuf[2] << 8) | RxBuf[3]  (16-bit value)
 */
int AD7616_ReadConversion(AD7616_Result *result)
{
    u8 TxBuf[4];
    u8 RxBuf[4];
    int Status;

    /* Fill TX buffer with zeros — we're just clocking data out of the ADC */
    memset(TxBuf, 0, 4);
    memset(RxBuf, 0, 4);

    /*
     * *** THE 32-BIT SPI TRANSFER ***
     *
     * ByteCount = 4 means 4 bytes = 32 bits.
     *
     * Because we use XSP_MANUAL_SSELECT_OPTION, CS stays LOW for
     * all 4 bytes (32 SCLK pulses). This is critical — the AD7616
     * needs exactly 32 continuous clocks to output both channel results.
     */
    Status = XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, 4);

    if (Status == XST_SUCCESS) {
        /*
         * Reassemble the two 16-bit results from 4 received bytes:
         *
         * Channel A (Side A) = first 16 bits:
         *   RxBuf[0] = bits [15:8] (MSB, received first)
         *   RxBuf[1] = bits [7:0]  (LSB)
         *   raw_a = (RxBuf[0] << 8) | RxBuf[1]
         *
         * Channel B (Side B) = next 16 bits:
         *   RxBuf[2] = bits [15:8]
         *   RxBuf[3] = bits [7:0]
         *   raw_b = (RxBuf[2] << 8) | RxBuf[3]
         */
        result->raw_a = ((u16)RxBuf[0] << 8) | (u16)RxBuf[1];
        result->raw_b = ((u16)RxBuf[2] << 8) | (u16)RxBuf[3];
    }

    return Status;
}


/*
 * AD7616_ConvertAndRead() — Complete conversion cycle: trigger → wait → read.
 *
 * This is the MAIN function most users will call. It does everything:
 *
 *   Step 1: Pulse CONVST (start conversion)
 *   Step 2: Poll BUSY until LOW (wait for conversion, ~1µs)
 *   Step 3: XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, 4)  (read 32-bit result)
 *   Step 4: Convert raw ADC codes to voltages using channel range settings
 *
 * Example:
 *   AD7616_Result result;
 *   AD7616_ConvertAndRead(&result);
 *   // result.raw_a = 0x4000 (raw 16-bit code)
 *   // result.volt_a = 5.0V  (for ±10V range)
 */
int AD7616_ConvertAndRead(AD7616_Result *result)
{
    u32 timeout = 10000;    /* Max 10,000 iterations × 1µs = 10ms timeout */
    int Status;

    /*
     * STEP 1: Trigger the conversion
     *
     * This pulses CONVST_A and CONVST_B LOW simultaneously.
     * The ADC begins the analog-to-digital conversion process.
     */
    AD7616_TriggerConversion();

    /*
     * STEP 2: Wait for conversion to complete
     *
     * After CONVST, the BUSY pin goes HIGH. It stays HIGH for the
     * duration of the conversion:
     *   - No oversampling: ~1 µs
     *   - 128x oversampling: ~128 µs
     *
     * We poll BUSY in a loop, checking every 1µs.
     * If it doesn't go LOW within 10ms, something is wrong.
     */
    while (AD7616_IsBusy() && (timeout > 0)) {
        usleep(1);     /* Wait 1 microsecond between checks */
        timeout--;
    }

    if (timeout == 0) {
        xil_printf("[AD7616] BUSY timeout!\r\n");
        return XST_FAILURE;
    }

    /*
     * STEP 3: Read conversion data via SPI
     *
     * Now that BUSY is LOW, the data is ready. We do a 32-bit SPI
     * transfer (4 bytes) to clock out the Channel A and Channel B results.
     */
    Status = AD7616_ReadConversion(result);
    if (Status != XST_SUCCESS)
        return Status;

    /*
     * STEP 4: Convert raw ADC codes to voltages
     *
     * We need to know which channels were just converted so we can
     * use the correct voltage range for the conversion formula.
     *
     * Read the channel register to find out which channels are active,
     * then look up their range in our gRangeA[]/gRangeB[] arrays.
     */
    u16 chReg;
    Status = AD7616_ReadReg(AD7616_REG_CHANNEL, &chReg);
    if (Status == XST_SUCCESS) {
        u8 chA = (chReg >> AD7616_CHA_SHIFT) & 0x0F;   /* Current Side A channel */
        u8 chB = (chReg >> AD7616_CHB_SHIFT) & 0x0F;   /* Current Side B channel */
        result->volt_a = AD7616_RawToVoltage(result->raw_a, gRangeA[chA]);
        result->volt_b = AD7616_RawToVoltage(result->raw_b, gRangeB[chB]);
    } else {
        /* Fallback: assume ±10V if we can't read the channel register */
        result->volt_a = AD7616_RawToVoltage(result->raw_a, AD7616_RANGE_PM10V);
        result->volt_b = AD7616_RawToVoltage(result->raw_b, AD7616_RANGE_PM10V);
    }

    return XST_SUCCESS;
}


/*==============================================================================
 *
 *  MULTI-CHANNEL — Read specific pairs or scan all 16 channels
 *
 *============================================================================*/

/*
 * AD7616_ReadChannelPair() — Select a pair, convert, and read in one call.
 *
 * This is a convenience function that chains:
 *   1. AD7616_SelectChannel(chA, chB)   → SPI write (1 transfer)
 *   2. AD7616_ConvertAndRead(&result)   → CONVST + BUSY + SPI read (3 transfers)
 *
 * Total: ~4 SPI transfers per pair = 4× XSpi_Transfer() calls.
 *
 * Example:
 *   AD7616_Result result;
 *   AD7616_ReadChannelPair(3, 5, &result);
 *   // result.volt_a = voltage on VA3
 *   // result.volt_b = voltage on VB5
 */
int AD7616_ReadChannelPair(u8 chA, u8 chB, AD7616_Result *result)
{
    int Status;

    /* Select the desired channel pair */
    Status = AD7616_SelectChannel(chA, chB);
    if (Status != XST_SUCCESS) return Status;

    /* Trigger, wait, and read */
    Status = AD7616_ConvertAndRead(result);
    if (Status != XST_SUCCESS) return Status;

    /* Override voltages with the correct range for the explicit channels */
    result->volt_a = AD7616_RawToVoltage(result->raw_a, gRangeA[chA]);
    result->volt_b = AD7616_RawToVoltage(result->raw_b, gRangeB[chB]);

    return XST_SUCCESS;
}


/*
 * AD7616_ScanAllChannels() — Read all 8 channel pairs (16 channels total).
 *
 * Iterates through VA0/VB0, VA1/VB1, ..., VA7/VB7 and stores each result.
 *
 * Total SPI transfers: 8 pairs × ~4 transfers each = ~32 XSpi_Transfer() calls.
 *
 * Example:
 *   AD7616_Result all[8];
 *   AD7616_ScanAllChannels(all);
 *
 *   // all[0].raw_a = VA0 raw code    all[0].volt_a = VA0 voltage
 *   // all[0].raw_b = VB0 raw code    all[0].volt_b = VB0 voltage
 *   // all[1].raw_a = VA1 raw code    all[1].volt_a = VA1 voltage
 *   // ...
 *   // all[7].raw_b = VB7 raw code    all[7].volt_b = VB7 voltage
 */
int AD7616_ScanAllChannels(AD7616_Result results[8])
{
    int i, Status;

    for (i = 0; i < 8; i++) {
        Status = AD7616_ReadChannelPair((u8)i, (u8)i, &results[i]);
        if (Status != XST_SUCCESS) {
            xil_printf("[AD7616] Scan failed on pair %d\r\n", i);
            return Status;
        }
    }

    return XST_SUCCESS;
}


/*==============================================================================
 *
 *  SEQUENCER
 *
 *  Instead of manually selecting channels before each conversion, the
 *  sequencer automatically cycles through a pre-programmed list.
 *
 *  The AD7616 has 8 "stack" registers per side (A and B). Each register
 *  holds a channel number. After enabling the sequencer:
 *    - 1st CONVST → converts channels in stack[0]
 *    - 2nd CONVST → converts channels in stack[1]
 *    - ...
 *    - Nth CONVST → converts channels in stack[N-1]
 *    - (N+1)th CONVST → wraps back to stack[0]
 *
 *============================================================================*/

/*
 * AD7616_SetupSequencer() — Program and enable the channel sequencer.
 *
 * Example: Sequence VA0/VB0 → VA3/VB3 → VA7/VB7
 *
 *   u8 sideA[] = {0, 3, 7};
 *   u8 sideB[] = {0, 3, 7};
 *   AD7616_SetupSequencer(sideA, sideB, 3);
 *
 * After this, just call AD7616_ConvertAndRead() repeatedly and it
 * automatically cycles: first call reads VA0/VB0, second reads VA3/VB3,
 * third reads VA7/VB7, fourth wraps back to VA0/VB0, etc.
 */
int AD7616_SetupSequencer(const u8 chA_list[], const u8 chB_list[], u8 numPairs)
{
    int i, Status;

    if (numPairs == 0 || numPairs > 8) return XST_FAILURE;

    /* Disable sequencer first (clean state) */
    AD7616_DisableSequencer();

    /*
     * Program the stack registers.
     *
     * For each position i in the sequence:
     *   Write chA_list[i] to SSREN_A register at address (0x20 + i)
     *   Write chB_list[i] to SSREN_B register at address (0x28 + i)
     */
    for (i = 0; i < (int)numPairs; i++) {
        Status = AD7616_WriteReg(AD7616_REG_SEQ_A(i), (u16)(chA_list[i] & 0x07));
        if (Status != XST_SUCCESS) return Status;

        Status = AD7616_WriteReg(AD7616_REG_SEQ_B(i), (u16)(chB_list[i] & 0x07));
        if (Status != XST_SUCCESS) return Status;
    }

    /*
     * Enable sequencer in the config register.
     *
     * Set SEQEN[1:0] = 10 (auto-sequence mode)
     * Set BURSTEN = 1 (burst mode for efficient readout)
     */
    gConfigReg &= ~AD7616_CFG_SEQEN_MASK;
    gConfigReg |= (0x02u << AD7616_CFG_SEQEN_SHIFT);   /* SEQEN = 10 = auto */
    gConfigReg |= AD7616_CFG_BURSTEN;                   /* Enable burst mode */

    Status = AD7616_WriteReg(AD7616_REG_CONFIG, gConfigReg);
    xil_printf("[AD7616] Sequencer enabled, %d pairs\r\n", numPairs);

    return Status;
}


/*
 * AD7616_DisableSequencer() — Turn off the sequencer.
 *
 * Clears SEQEN and BURSTEN bits in the config register.
 * After this, the ADC returns to manual channel selection mode.
 */
int AD7616_DisableSequencer(void)
{
    gConfigReg &= ~AD7616_CFG_SEQEN_MASK;   /* Clear SEQEN bits */
    gConfigReg &= ~AD7616_CFG_BURSTEN;      /* Clear burst mode */

    return AD7616_WriteReg(AD7616_REG_CONFIG, gConfigReg);
}


/*==============================================================================
 *
 *  UTILITIES
 *
 *============================================================================*/

/*
 * AD7616_RawToVoltage() — Convert a 16-bit ADC code to voltage.
 *
 * THE MATH:
 *
 * For BIPOLAR ranges (±10V, ±5V, ±2.5V):
 *   The ADC outputs 16-bit TWOS COMPLEMENT (signed integer):
 *
 *     Raw Code  │ As s16 │ Voltage (±10V range)
 *     ──────────┼────────┼─────────────────────
 *     0x7FFF    │ +32767 │ +9.99969V  (max positive)
 *     0x4000    │ +16384 │ +5.0V
 *     0x0001    │ +1     │ +0.000305V (1 LSB)
 *     0x0000    │  0     │  0.0V
 *     0xFFFF    │ -1     │ -0.000305V
 *     0xC000    │ -16384 │ -5.0V
 *     0x8000    │ -32768 │ -10.0V     (max negative)
 *
 *   Formula: voltage = (s16)raw / 32768.0 * FullScale
 *
 *   Why 32768? Because the ADC has 16 bits, and in twos complement,
 *   the range is -32768 to +32767. Dividing by 32768 normalizes to -1.0 to +0.99997.
 *
 * For UNIPOLAR range (0-10V):
 *   The ADC outputs 16-bit UNSIGNED integer:
 *
 *     Raw Code  │ As u16 │ Voltage
 *     ──────────┼────────┼─────────────
 *     0xFFFF    │ 65535  │ 9.99985V
 *     0x8000    │ 32768  │ 5.0V
 *     0x0001    │ 1      │ 0.000153V
 *     0x0000    │ 0      │ 0.0V
 *
 *   Formula: voltage = raw / 65536.0 * FullScale
 */
float AD7616_RawToVoltage(u16 raw, AD7616_Range range)
{
    float fs = gFullScale[range & 0x03];   /* Look up full-scale voltage */

    if (range == AD7616_RANGE_0_10V) {
        /* UNIPOLAR: treat raw as unsigned 16-bit, scale to 0..FullScale */
        return ((float)raw / 65536.0f) * fs;
    } else {
        /*
         * BIPOLAR: cast raw to signed 16-bit (s16), scale to -FS..+FS
         *
         * The cast (s16)raw reinterprets the bit pattern:
         *   0x8000 → -32768
         *   0xFFFF → -1
         *   0x0000 → 0
         *   0x7FFF → +32767
         */
        return ((float)((s16)raw) / 32768.0f) * fs;
    }
}


/*
 * AD7616_PrintResult() — Print one conversion result to UART.
 *
 * OUTPUT FORMAT:
 *   "VA3: 0x1A3F =  3.247V | VB5: 0xE012 = -3.891V"
 *
 * NOTE: xil_printf() does NOT support %f (floating point).
 * So we convert voltage to millivolts (integer) and print as X.XXXV.
 *
 * Example: voltage = -3.891V
 *   mV = (int)(-3.891 * 1000) = -3891
 *   Print: "-3.891V" → sign="-", integer=3, fraction=891
 */
void AD7616_PrintResult(u8 chA, u8 chB, const AD7616_Result *result)
{
    /* Convert float voltages to integer millivolts */
    s32 mV_A = (s32)(result->volt_a * 1000.0f);
    s32 mV_B = (s32)(result->volt_b * 1000.0f);

    /* Get absolute values for printing (we handle sign separately) */
    s32 absA = (mV_A < 0) ? -mV_A : mV_A;
    s32 absB = (mV_B < 0) ? -mV_B : mV_B;

    /*
     * Print format: "VA0: 0x1234 =  1.234V | VB0: 0x5678 =  5.678V"
     *
     * absA / 1000 = integer part  (e.g., 3)
     * absA % 1000 = fractional part in millivolts (e.g., 891)
     * %03d pads with zeros: 891 → "891", 5 → "005"
     */
    xil_printf("VA%d: 0x%04X = %s%d.%03dV | VB%d: 0x%04X = %s%d.%03dV\r\n",
               chA, result->raw_a,
               (mV_A < 0) ? "-" : " ", absA / 1000, absA % 1000,
               chB, result->raw_b,
               (mV_B < 0) ? "-" : " ", absB / 1000, absB % 1000);
}
