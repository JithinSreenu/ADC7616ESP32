#include "AD7616.h"
#include <string.h>

/* Pin mapping – can be overridden in sketch */
#ifndef AD7616_CS_PIN
#define AD7616_CS_PIN   5
#endif
#ifndef AD7616_CONVST_A_PIN
#define AD7616_CONVST_A_PIN 15
#endif
#ifndef AD7616_CONVST_B_PIN
#define AD7616_CONVST_B_PIN 2
#endif
#ifndef AD7616_RESET_PIN
#define AD7616_RESET_PIN 4
#endif
#ifndef AD7616_BUSY_PIN
#define AD7616_BUSY_PIN 34
#endif

/* Register map */
#define AD7616_REG_CONFIG       0x02u
#define AD7616_REG_CHANNEL      0x03u
#define AD7616_REG_RANGE_A1     0x04u
#define AD7616_REG_RANGE_A2     0x05u
#define AD7616_REG_RANGE_A3     0x08u
#define AD7616_REG_RANGE_A4     0x09u
#define AD7616_REG_RANGE_B1     0x06u
#define AD7616_REG_RANGE_B2     0x07u
#define AD7616_REG_RANGE_B3     0x0Au
#define AD7616_REG_RANGE_B4     0x0Bu
#define AD7616_REG_SEQ_A(n)     (0x20u + (n))
#define AD7616_REG_SEQ_B(n)     (0x28u + (n))

#define AD7616_WR_CMD(addr,data) ((uint16_t)(0x8000 | (((addr)&0x3F)<<9) | ((data)&0x1FF)))
#define AD7616_RD_CMD(addr)      ((uint16_t)(((addr)&0x3F)<<9))

#define AD7616_CFG_OS_SHIFT 3
#define AD7616_CFG_OS_MASK  (0x07u<<3)
#define AD7616_CFG_SEQEN_SHIFT 1
#define AD7616_CFG_SEQEN_MASK (0x03u<<1)
#define AD7616_CFG_BURSTEN (1u<<0)

#define AD7616_CHA_SHIFT 0
#define AD7616_CHB_SHIFT 4

#define AD7616_RANGE_EVEN_SHIFT 0
#define AD7616_RANGE_ODD_SHIFT 3

static uint16_t gConfigReg = 0x000;
static AD7616_Range gRangeA[8];
static AD7616_Range gRangeB[8];
static const float gFullScale[] = {10.0f,2.5f,5.0f,10.0f};

static const uint8_t gRangeRegA[] = {AD7616_REG_RANGE_A1,AD7616_REG_RANGE_A2,AD7616_REG_RANGE_A3,AD7616_REG_RANGE_A4};
static const uint8_t gRangeRegB[] = {AD7616_REG_RANGE_B1,AD7616_REG_RANGE_B2,AD7616_REG_RANGE_B3,AD7616_REG_RANGE_B4};

static inline void GpioSet(uint8_t pin, int v){ digitalWrite(pin, v?HIGH:LOW); }
static inline int GpioGet(uint8_t pin){ return digitalRead(pin); }

static void ad7616_spiTransferBytes(const uint8_t *tx, uint8_t *rx, size_t len){
    SPI.beginTransaction(SPISettings(10000000, MSBFIRST, SPI_MODE2));
    digitalWrite(AD7616_CS_PIN, LOW);
    for(size_t i=0;i<len;i++){
        uint8_t t = tx ? tx[i] : 0x00;
        uint8_t r = SPI.transfer(t);
        if(rx) rx[i]=r;
    }
    digitalWrite(AD7616_CS_PIN, HIGH);
    SPI.endTransaction();
}

int AD7616_Init(void){
    pinMode(AD7616_CS_PIN, OUTPUT);
    digitalWrite(AD7616_CS_PIN, HIGH);
    pinMode(AD7616_CONVST_A_PIN, OUTPUT);
    pinMode(AD7616_CONVST_B_PIN, OUTPUT);
    pinMode(AD7616_RESET_PIN, OUTPUT);
    pinMode(AD7616_BUSY_PIN, INPUT);
    GpioSet(AD7616_CONVST_A_PIN,1);
    GpioSet(AD7616_CONVST_B_PIN,1);
    GpioSet(AD7616_RESET_PIN,1);
    AD7616_HardReset();
    for(int i=0;i<8;i++){ gRangeA[i]=AD7616_RANGE_PM10V; gRangeB[i]=AD7616_RANGE_PM10V; }
    gConfigReg=0;
    uint16_t rb;
    if(AD7616_ReadReg(AD7616_REG_CONFIG,&rb)!=0) return -1;
    Serial.printf("[AD7616] Init OK, config=0x%03X\n", rb&0x1FF);
    AD7616_SelectChannel(0,0);
    return 0;
}

void AD7616_HardReset(void){
    GpioSet(AD7616_RESET_PIN,0);
    delayMicroseconds(10);
    GpioSet(AD7616_RESET_PIN,1);
    delay(1);
    Serial.println("[AD7616] Hardware reset done");
}

int AD7616_WriteReg(uint8_t addr, uint16_t data){
    uint16_t cmd = AD7616_WR_CMD(addr,data);
    uint8_t tx[2] = {(uint8_t)(cmd>>8),(uint8_t)(cmd&0xFF)};
    ad7616_spiTransferBytes(tx,NULL,2);
    return 0;
}

int AD7616_ReadReg(uint8_t addr, uint16_t *data){
    uint16_t cmd = AD7616_RD_CMD(addr);
    uint8_t tx[2] = {(uint8_t)(cmd>>8),(uint8_t)(cmd&0xFF)};
    uint8_t rx[2];
    ad7616_spiTransferBytes(tx,rx,2);
    uint8_t tx2[2]={0,0};
    uint8_t rx2[2];
    ad7616_spiTransferBytes(tx2,rx2,2);
    *data = ((uint16_t)rx2[0]<<8 | rx2[1]) & 0x1FF;
    return 0;
}

int AD7616_SelectChannel(uint8_t chA, uint8_t chB){
    if(chA>7||chB>7) return -1;
    uint16_t v = ((uint16_t)(chB&0x0F)<<AD7616_CHB_SHIFT) | ((uint16_t)(chA&0x0F)<<AD7616_CHA_SHIFT);
    return AD7616_WriteReg(AD7616_REG_CHANNEL,v);
}

int AD7616_SetRangeA(uint8_t ch, AD7616_Range range){
    if(ch>7) return -1;
    uint8_t regAddr = gRangeRegA[ch/2];
    uint16_t regVal;
    AD7616_ReadReg(regAddr,&regVal);
    if(ch&1){
        regVal &= ~(0x07u<<AD7616_RANGE_ODD_SHIFT);
        regVal |= ((uint16_t)range<<AD7616_RANGE_ODD_SHIFT);
    }else{
        regVal &= ~(0x07u<<AD7616_RANGE_EVEN_SHIFT);
        regVal |= ((uint16_t)range<<AD7616_RANGE_EVEN_SHIFT);
    }
    AD7616_WriteReg(regAddr,regVal);
    gRangeA[ch]=range;
    return 0;
}

int AD7616_SetRangeB(uint8_t ch, AD7616_Range range){
    if(ch>7) return -1;
    uint8_t regAddr = gRangeRegB[ch/2];
    uint16_t regVal;
    AD7616_ReadReg(regAddr,&regVal);
    if(ch&1){
        regVal &= ~(0x07u<<AD7616_RANGE_ODD_SHIFT);
        regVal |= ((uint16_t)range<<AD7616_RANGE_ODD_SHIFT);
    }else{
        regVal &= ~(0x07u<<AD7616_RANGE_EVEN_SHIFT);
        regVal |= ((uint16_t)range<<AD7616_RANGE_EVEN_SHIFT);
    }
    AD7616_WriteReg(regAddr,regVal);
    gRangeB[ch]=range;
    return 0;
}

int AD7616_SetRangeAll(AD7616_Range range){
    uint16_t regVal = ((uint16_t)range<<AD7616_RANGE_ODD_SHIFT) | ((uint16_t)range<<AD7616_RANGE_EVEN_SHIFT);
    for(int i=0;i<4;i++){
        AD7616_WriteReg(gRangeRegA[i],regVal);
        AD7616_WriteReg(gRangeRegB[i],regVal);
    }
    for(int i=0;i<8;i++){ gRangeA[i]=range; gRangeB[i]=range; }
    return 0;
}

int AD7616_SetOversampling(AD7616_Oversample ratio){
    gConfigReg &= ~AD7616_CFG_OS_MASK;
    gConfigReg |= ((uint16_t)ratio<<AD7616_CFG_OS_SHIFT) & AD7616_CFG_OS_MASK;
    return AD7616_WriteReg(AD7616_REG_CONFIG,gConfigReg);
}

void AD7616_TriggerConversion(void){
    GpioSet(AD7616_CONVST_A_PIN,0);
    GpioSet(AD7616_CONVST_B_PIN,0);
    delayMicroseconds(1);
    GpioSet(AD7616_CONVST_A_PIN,1);
    GpioSet(AD7616_CONVST_B_PIN,1);
}

int AD7616_IsBusy(void){
    return GpioGet(AD7616_BUSY_PIN);
}

int AD7616_ReadConversion(AD7616_Result *result){
    uint8_t tx[4]={0,0,0,0};
    uint8_t rx[4];
    ad7616_spiTransferBytes(tx,rx,4);
    result->raw_a = ((uint16_t)rx[0]<<8)|rx[1];
    result->raw_b = ((uint16_t)rx[2]<<8)|rx[3];
    return 0;
}

int AD7616_ConvertAndRead(AD7616_Result *result){
    AD7616_TriggerConversion();
    uint32_t to=10000;
    while(AD7616_IsBusy() && to--) delayMicroseconds(1);
    if(to==0) return -1;
    AD7616_ReadConversion(result);
    uint16_t chReg;
    AD7616_ReadReg(AD7616_REG_CHANNEL,&chReg);
    uint8_t chA = (chReg>>AD7616_CHA_SHIFT)&0x0F;
    uint8_t chB = (chReg>>AD7616_CHB_SHIFT)&0x0F;
    result->volt_a = AD7616_RawToVoltage(result->raw_a,gRangeA[chA]);
    result->volt_b = AD7616_RawToVoltage(result->raw_b,gRangeB[chB]);
    return 0;
}

int AD7616_ReadChannelPair(uint8_t chA, uint8_t chB, AD7616_Result *result){
    AD7616_SelectChannel(chA,chB);
    AD7616_ConvertAndRead(result);
    result->volt_a = AD7616_RawToVoltage(result->raw_a,gRangeA[chA]);
    result->volt_b = AD7616_RawToVoltage(result->raw_b,gRangeB[chB]);
    return 0;
}

int AD7616_ScanAllChannels(AD7616_Result results[8]){
    for(int i=0;i<8;i++){
        if(AD7616_ReadChannelPair(i,i,&results[i])!=0) return -1;
    }
    return 0;
}

int AD7616_SetupSequencer(const uint8_t chA_list[], const uint8_t chB_list[], uint8_t numPairs){
    if(numPairs==0||numPairs>8) return -1;
    AD7616_DisableSequencer();
    for(int i=0;i<numPairs;i++){
        AD7616_WriteReg(AD7616_REG_SEQ_A(i), chA_list[i]&0x07);
        AD7616_WriteReg(AD7616_REG_SEQ_B(i), chB_list[i]&0x07);
    }
    gConfigReg &= ~AD7616_CFG_SEQEN_MASK;
    gConfigReg |= (0x02u<<AD7616_CFG_SEQEN_SHIFT);
    gConfigReg |= AD7616_CFG_BURSTEN;
    AD7616_WriteReg(AD7616_REG_CONFIG,gConfigReg);
    return 0;
}

int AD7616_DisableSequencer(void){
    gConfigReg &= ~AD7616_CFG_SEQEN_MASK;
    gConfigReg &= ~AD7616_CFG_BURSTEN;
    return AD7616_WriteReg(AD7616_REG_CONFIG,gConfigReg);
}

float AD7616_RawToVoltage(uint16_t raw, AD7616_Range range){
    float fs = gFullScale[range&0x03];
    if(range==AD7616_RANGE_0_10V){
        return ((float)raw/65536.0f)*fs;
    }else{
        return ((float)((int16_t)raw)/32768.0f)*fs;
    }
}

void AD7616_PrintResult(uint8_t chA, uint8_t chB, const AD7616_Result *result){
    int32_t mV_A = (int32_t)(result->volt_a*1000.0f);
    int32_t mV_B = (int32_t)(result->volt_b*1000.0f);
    int32_t aA = mV_A<0?-mV_A:mV_A;
    int32_t aB = mV_B<0?-mV_B:mV_B;
    Serial.printf("VA%d: 0x%04X = %c%d.%03dV | VB%d: 0x%04X = %c%d.%03dV\n",
        chA,result->raw_a, mV_A<0?'-':' ', aA/1000, aA%1000,
        chB,result->raw_b, mV_B<0?'-':' ', aB/1000, aB%1000);
}
