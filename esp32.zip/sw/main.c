/******************************************************************************
 * @file    main.c
 * @brief   AD7616 ADC Demo — ZedBoard (Zynq-7020)
 *
 * Uses XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, ByteCount) throughout.
 * UART output at 115200 baud.
 *****************************************************************************/

#include "xparameters.h"
#include "xspi.h"
#include "xgpio.h"
#include "xil_printf.h"
#include "sleep.h"
#include "platform.h"

#include "ad7616_drv.h"

/*============================================================================
 * GLOBAL INSTANCES — shared with ad7616_drv.c via extern
 *===========================================================================*/
XSpi  SpiInstance;
XGpio GpioInstance;

/*============================================================================
 * DEVICE IDs — update to match your xparameters.h
 *===========================================================================*/
#define SPI_DEVICE_ID   XPAR_SPI_0_DEVICE_ID
#define GPIO_DEVICE_ID  XPAR_GPIO_0_DEVICE_ID

/*============================================================================
 * FUNCTION PROTOTYPES
 *===========================================================================*/
static int InitSpi(void);
static int InitGpio(void);

/*============================================================================
 * MAIN
 *===========================================================================*/
int main(void)
{
    int Status;
    AD7616_Result result;
    AD7616_Result allResults[8];
    int i;

    init_platform();

    xil_printf("\r\n========================================\r\n");
    xil_printf("  AD7616 SPI Driver — ZedBoard\r\n");
    xil_printf("  16-ch, 16-bit Dual SAR ADC\r\n");
    xil_printf("========================================\r\n\r\n");

    /*--- Init SPI ---*/
    Status = InitSpi();
    if (Status != XST_SUCCESS) {
        xil_printf("SPI init FAILED\r\n");
        return -1;
    }
    xil_printf("SPI init OK\r\n");

    /*--- Init GPIO ---*/
    Status = InitGpio();
    if (Status != XST_SUCCESS) {
        xil_printf("GPIO init FAILED\r\n");
        return -1;
    }
    xil_printf("GPIO init OK\r\n");

    /*--- Init AD7616 ---*/
    Status = AD7616_Init();
    if (Status != XST_SUCCESS) {
        xil_printf("AD7616 init FAILED\r\n");
        return -1;
    }

    /*--- Set all channels to +/-10V ---*/
    AD7616_SetRangeAll(AD7616_RANGE_PM10V);

    /*=== DEMO 1: Read single pair VA0/VB0, 10 times ===*/
    xil_printf("\r\n--- Single Pair (VA0/VB0) ---\r\n");
    for (i = 0; i < 10; i++) {
        Status = AD7616_ReadChannelPair(0, 0, &result);
        if (Status == XST_SUCCESS) {
            AD7616_PrintResult(0, 0, &result);
        }
        usleep(100000);
    }

    /*=== DEMO 2: Read specific pairs ===*/
    xil_printf("\r\n--- Specific Pairs ---\r\n");

    AD7616_ReadChannelPair(2, 3, &result);   /* VA2 / VB3 */
    AD7616_PrintResult(2, 3, &result);

    AD7616_ReadChannelPair(5, 5, &result);   /* VA5 / VB5 */
    AD7616_PrintResult(5, 5, &result);

    AD7616_ReadChannelPair(7, 7, &result);   /* VA7 / VB7 */
    AD7616_PrintResult(7, 7, &result);

    /*=== DEMO 3: Scan all 16 channels ===*/
    xil_printf("\r\n--- Full 16-Channel Scan ---\r\n");
    Status = AD7616_ScanAllChannels(allResults);
    if (Status == XST_SUCCESS) {
        for (i = 0; i < 8; i++) {
            AD7616_PrintResult(i, i, &allResults[i]);
        }
    }

    /*=== Continuous loop: scan all channels every second ===*/
    xil_printf("\r\n--- Continuous Scan (1 Hz) ---\r\n");
    while (1) {
        Status = AD7616_ScanAllChannels(allResults);
        if (Status == XST_SUCCESS) {
            xil_printf("----\r\n");
            for (i = 0; i < 8; i++) {
                AD7616_PrintResult(i, i, &allResults[i]);
            }
        }
        sleep(1);
    }

    cleanup_platform();
    return 0;
}

/*============================================================================
 * SPI INIT — CPOL=1, CPHA=0 (SPI Mode 2), Master, Manual CS
 *===========================================================================*/
static int InitSpi(void)
{
    XSpi_Config *cfg;
    int Status;

    cfg = XSpi_LookupConfig(SPI_DEVICE_ID);
    if (!cfg) return XST_FAILURE;

    Status = XSpi_CfgInitialize(&SpiInstance, cfg, cfg->BaseAddress);
    if (Status != XST_SUCCESS) return Status;

    Status = XSpi_SetOptions(&SpiInstance,
                              XSP_MASTER_OPTION |
                              XSP_CLK_ACTIVE_LOW_OPTION |
                              XSP_MANUAL_SSELECT_OPTION);
    if (Status != XST_SUCCESS) return Status;

    XSpi_SetSlaveSelect(&SpiInstance, 0x01);
    XSpi_Start(&SpiInstance);
    XSpi_IntrGlobalDisable(&SpiInstance);

    return XST_SUCCESS;
}

/*============================================================================
 * GPIO INIT — Ch1: outputs (CONVST, RESET), Ch2: input (BUSY)
 *===========================================================================*/
static int InitGpio(void)
{
    int Status;

    Status = XGpio_Initialize(&GpioInstance, GPIO_DEVICE_ID);
    if (Status != XST_SUCCESS) return Status;

    XGpio_SetDataDirection(&GpioInstance, 1, 0x00000000);  /* Ch1 = outputs */
    XGpio_SetDataDirection(&GpioInstance, 2, 0xFFFFFFFF);  /* Ch2 = inputs  */

    return XST_SUCCESS;
}
