#include "AD7616.h"

/* Pin mapping can also be changed here */
#define AD7616_CS_PIN 5
#define AD7616_CONVST_A_PIN 15
#define AD7616_CONVST_B_PIN 2
#define AD7616_RESET_PIN 4
#define AD7616_BUSY_PIN 34

void setup(){
  Serial.begin(115200);
  delay(500);
  Serial.println("\nAD7616 ESP32 demo");

  SPI.begin(18,34,23,5); // SCK,MISO,MOSI,SS
  AD7616_Init();
  AD7616_SetRangeAll(AD7616_RANGE_PM10V);
}

void loop(){
  AD7616_Result r;
  if(AD7616_ReadChannelPair(0,0,&r)==0){
    AD7616_PrintResult(0,0,&r);
  }
  delay(500);
}
