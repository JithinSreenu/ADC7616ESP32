/******************************************************************************
 * @file    ad7616_drv.h
 * @brief   AD7616 16-bit Dual SAR ADC - SPI Driver (Zynq / AXI Quad SPI)
 *
 * Uses XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, ByteCount) directly.
 *
 * SPI Mode 2: CPOL=1, CPHA=0
 *****************************************************************************/

#ifndef AD7616_DRV_H
#define AD7616_DRV_H

#include "xspi.h"
#include "xgpio.h"
#include "xil_types.h"
#include "xstatus.h"

/*============================================================================
 * EXTERN INSTANCES — Declare in main.c, shared with driver
 *===========================================================================*/
extern XSpi  SpiInstance;
extern XGpio GpioInstance;

/*============================================================================
 * AD7616 SPI FRAME FORMAT
 *
 * 16-bit word:
 *   Bit [15]    : WR (1=Write, 0=Read)
 *   Bits [14:9] : Register Address (6 bits)
 *   Bits [8:0]  : Data (9 bits)
 *===========================================================================*/
#define AD7616_WR_CMD(addr, data)  ((u16)(0x8000 | (((addr) & 0x3F) << 9) | ((data) & 0x1FF)))
#define AD7616_RD_CMD(addr)        ((u16)(((addr) & 0x3F) << 9))
#define AD7616_NOP                 0x0000u

/*============================================================================
 * REGISTER MAP
 *===========================================================================*/
#define AD7616_REG_CONFIG       0x02u
#define AD7616_REG_CHANNEL      0x03u

/* Input range registers — Side A */
#define AD7616_REG_RANGE_A1     0x04u   /* VA0, VA1 */
#define AD7616_REG_RANGE_A2     0x05u   /* VA2, VA3 */
#define AD7616_REG_RANGE_A3     0x08u   /* VA4, VA5 */
#define AD7616_REG_RANGE_A4     0x09u   /* VA6, VA7 */

/* Input range registers — Side B */
#define AD7616_REG_RANGE_B1     0x06u   /* VB0, VB1 */
#define AD7616_REG_RANGE_B2     0x07u   /* VB2, VB3 */
#define AD7616_REG_RANGE_B3     0x0Au   /* VB4, VB5 */
#define AD7616_REG_RANGE_B4     0x0Bu   /* VB6, VB7 */

/* Sequencer stack registers */
#define AD7616_REG_SEQ_A(n)     (0x20u + (n))   /* n = 0..7 */
#define AD7616_REG_SEQ_B(n)     (0x28u + (n))   /* n = 0..7 */

/*============================================================================
 * CONFIG REGISTER (0x02) BITS
 *===========================================================================*/
#define AD7616_CFG_STATUSEN     (1u << 7)
#define AD7616_CFG_CRCEN        (1u << 6)
#define AD7616_CFG_OS_SHIFT     3
#define AD7616_CFG_OS_MASK      (0x07u << 3)
#define AD7616_CFG_SEQEN_SHIFT  1
#define AD7616_CFG_SEQEN_MASK   (0x03u << 1)
#define AD7616_CFG_BURSTEN      (1u << 0)

/*============================================================================
 * CHANNEL REGISTER (0x03) BITS
 *===========================================================================*/
#define AD7616_CHA_SHIFT        0
#define AD7616_CHB_SHIFT        4

/*============================================================================
 * RANGE REGISTER BITS
 *===========================================================================*/
#define AD7616_RANGE_EVEN_SHIFT 0
#define AD7616_RANGE_ODD_SHIFT  3

/*============================================================================
 * ENUMERATIONS
 *===========================================================================*/

/** Input voltage range */
typedef enum {
    AD7616_RANGE_PM10V = 0,   /* +/-10V  (bipolar)  */
    AD7616_RANGE_PM2V5 = 1,   /* +/-2.5V (bipolar)  */
    AD7616_RANGE_PM5V  = 2,   /* +/-5V   (bipolar)  */
    AD7616_RANGE_0_10V = 3    /* 0-10V   (unipolar) */
} AD7616_Range;

/** Oversampling ratio */
typedef enum {
    AD7616_OS_NONE = 0,
    AD7616_OS_2X   = 1,
    AD7616_OS_4X   = 2,
    AD7616_OS_8X   = 3,
    AD7616_OS_16X  = 4,
    AD7616_OS_32X  = 5,
    AD7616_OS_64X  = 6,
    AD7616_OS_128X = 7
} AD7616_Oversample;

/** Conversion result for one simultaneous A/B pair */
typedef struct {
    u16   raw_a;    /* Raw 16-bit code from Side A */
    u16   raw_b;    /* Raw 16-bit code from Side B */
    float volt_a;   /* Voltage from Side A         */
    float volt_b;   /* Voltage from Side B         */
} AD7616_Result;

/*============================================================================
 * GPIO PIN MAPPING — Change to match your AXI GPIO design
 *
 *   GPIO Channel 1 (outputs): CONVST_A, CONVST_B, RESET
 *   GPIO Channel 2 (input) :  BUSY
 *===========================================================================*/
#define AD7616_GPIO_OUT_CH      1
#define AD7616_GPIO_IN_CH       2

#define AD7616_PIN_CONVST_A     (1u << 0)
#define AD7616_PIN_CONVST_B     (1u << 1)
#define AD7616_PIN_RESET        (1u << 2)
#define AD7616_PIN_BUSY         (1u << 0)

/*============================================================================
 * PUBLIC API
 *===========================================================================*/

/* Initialization */
int  AD7616_Init(void);
void AD7616_HardReset(void);

/* Register access */
int  AD7616_WriteReg(u8 addr, u16 data);
int  AD7616_ReadReg(u8 addr, u16 *data);

/* Channel selection (manual mode) */
int  AD7616_SelectChannel(u8 chA, u8 chB);

/* Input range */
int  AD7616_SetRangeA(u8 ch, AD7616_Range range);
int  AD7616_SetRangeB(u8 ch, AD7616_Range range);
int  AD7616_SetRangeAll(AD7616_Range range);

/* Oversampling */
int  AD7616_SetOversampling(AD7616_Oversample ratio);

/* Conversion */
int  AD7616_ConvertAndRead(AD7616_Result *result);
void AD7616_TriggerConversion(void);
int  AD7616_IsBusy(void);
int  AD7616_ReadConversion(AD7616_Result *result);

/* Multi-channel */
int  AD7616_ReadChannelPair(u8 chA, u8 chB, AD7616_Result *result);
int  AD7616_ScanAllChannels(AD7616_Result results[8]);

/* Sequencer */
int  AD7616_SetupSequencer(const u8 chA_list[], const u8 chB_list[], u8 numPairs);
int  AD7616_DisableSequencer(void);

/* Utility */
float AD7616_RawToVoltage(u16 raw, AD7616_Range range);
void  AD7616_PrintResult(u8 chA, u8 chB, const AD7616_Result *result);

#endif /* AD7616_DRV_H */
