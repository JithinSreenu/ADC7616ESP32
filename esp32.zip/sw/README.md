# AD7616 SPI Driver – Zynq / ZedBoard

## Overview
Zynq-7000 software for the Analog Devices AD7616 16-bit, 1 MSPS dual simultaneous sampling SAR ADC.
The driver talks to the ADC over AXI Quad SPI and controls CONVST_A, CONVST_B, RESET and BUSY via AXI GPIO.

16 analog inputs are accessed as two sides:
- Side A: VA0 … VA7
- Side B: VB0 … VB7

Each conversion samples one channel from Side A and one from Side B at the same instant.

## Project Structure
```
sw/
  main.c                  – Demo application, SPI/GPIO init and scan loop
  ad7616_drv.h            – Production driver header
  ad7616_drv.c            – Production driver implementation
  ad7616_drv_explained.h  – Fully commented header for education
  ad7616_drv_explained.c  – Fully commented implementation, line-by-line SPI explanation
  README.md               – This file
```

## Hardware Interface
- SPI: AXI Quad SPI IP, Mode 2 CPOL=1 CPHA=0, manual chip select
  - `XSpi_Transfer(&SpiInstance, TxBuf, RxBuf, ByteCount)`
  - 2 bytes for register read/write, 4 bytes for conversion data
- GPIO:
  - Channel 1 outputs: CONVST_A bit0, CONVST_B bit1, RESET bit2
  - Channel 2 input: BUSY bit0
- Device IDs – update to match `xparameters.h`
  - `SPI_DEVICE_ID = XPAR_SPI_0_DEVICE_ID`
  - `GPIO_DEVICE_ID = XPAR_GPIO_0_DEVICE_ID`

## SPI Frame Format
16-bit word: `[15] WR 1=Write/0=Read | [14:9] Register Addr | [8:0] Data`
- Write: `AD7616_WR_CMD(addr,data) = 0x8000 | addr<<9 | data`
- Read: 2 SPI transfers – send read command, then NOP to clock data back

## Key Features
- Register read/write, channel selection, per-channel input range
- Oversampling 1× to 128× via config register shadow `gConfigReg`
- Manual mode and hardware sequencer with burst mode
- Raw to voltage conversion for bipolar ±10V / ±5V / ±2.5V and unipolar 0-10V
- Multi-channel helpers: `AD7616_ReadChannelPair`, `AD7616_ScanAllChannels`
- Detailed print helper `AD7616_PrintResult`

## Quick Start
1. Initialize platform, SPI and GPIO in `main.c`
   ```c
   InitSpi();
   InitGpio();
   AD7616_Init();
   AD7616_SetRangeAll(AD7616_RANGE_PM10V);
   ```
2. Read a pair
   ```c
   AD7616_Result r;
   AD7616_ReadChannelPair(0,0,&r);
   AD7616_PrintResult(0,0,&r);
   ```
3. Scan all 16 channels
   ```c
   AD7616_Result all[8];
   AD7616_ScanAllChannels(all);
   ```

## API Summary
Initialization
- `int AD7616_Init(void)`
- `void AD7616_HardReset(void)`

Register access
- `int AD7616_WriteReg(u8 addr, u16 data)`
- `int AD7616_ReadReg(u8 addr, u16 *data)`

Channel / Range
- `int AD7616_SelectChannel(u8 chA, u8 chB)`
- `int AD7616_SetRangeA(u8 ch, AD7616_Range range)`
- `int AD7616_SetRangeB(u8 ch, AD7616_Range range)`
- `int AD7616_SetRangeAll(AD7616_Range range)`

Oversampling
- `int AD7616_SetOversampling(AD7616_Oversample ratio)`

Conversion
- `int AD7616_ConvertAndRead(AD7616_Result *result)`
- `void AD7616_TriggerConversion(void)`
- `int AD7616_IsBusy(void)`
- `int AD7616_ReadConversion(AD7616_Result *result)`

Multi-channel
- `int AD7616_ReadChannelPair(u8 chA, u8 chB, AD7616_Result *result)`
- `int AD7616_ScanAllChannels(AD7616_Result results[8])`

Sequencer
- `int AD7616_SetupSequencer(const u8 chA_list[], const u8 chB_list[], u8 numPairs)`
- `int AD7616_DisableSequencer(void)`

Utilities
- `float AD7616_RawToVoltage(u16 raw, AD7616_Range range)`
- `void AD7616_PrintResult(u8 chA, u8 chB, const AD7616_Result *result)`

## Explained Version
`ad7616_drv_explained.h/c` is a line-by-line commented copy of the driver.
Every SPI transfer, bit field and timing is documented for education.
Functionally identical to the production driver.

## Notes
- xil_printf does not support %f; voltages are printed as millivolts in `AD7616_PrintResult`
- After reset default ranges are ±10V, channel pair VA0/VB0, oversampling off
- BUSY is HIGH during conversion ~1 µs at 1 MSPS, longer with oversampling
